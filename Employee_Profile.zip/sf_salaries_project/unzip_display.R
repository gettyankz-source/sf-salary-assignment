# =============================================================================
# unzip_display.R
# Task 6 – Unzip "Employee Profile.zip" and display the employee CSV data in R
#
# USAGE:
#   1. Run Task 5 in SF_Salaries_Assignment.ipynb first to generate
#      "Employee Profile.zip" in the project folder.
#   2. Set your working directory to sf_salaries_project/:
#         setwd("/path/to/sf_salaries_project")
#   3. Run:
#         source("unzip_display.R")
#      OR from the terminal:
#         Rscript unzip_display.R
#
# REQUIRED PACKAGES:
#   install.packages("readr")
# =============================================================================

library(utils)   # unzip() — built-in
library(readr)   # read_csv()

cat("=============================================================\n")
cat(" Task 6 – Unzip Employee Profile & Display Data\n")
cat("=============================================================\n\n")

# -----------------------------------------------------------------------------
# Step 1: Check that Employee Profile.zip exists
# -----------------------------------------------------------------------------
zip_path <- "Employee Profile.zip"

if (!file.exists(zip_path)) {
  stop(paste(
    "'Employee Profile.zip' not found in the current directory.\n",
    "Please run Task 5 in the Jupyter Notebook first."
  ))
}

cat("Found ZIP:", zip_path, "\n\n")

# -----------------------------------------------------------------------------
# Step 2: Unzip into "Employee Profile extracted/"
# -----------------------------------------------------------------------------
extract_dir <- "Employee Profile extracted"
dir.create(extract_dir, showWarnings = FALSE, recursive = TRUE)

cat("Extracting to:", extract_dir, "\n")
unzip(zip_path, exdir = extract_dir)
cat("Extraction complete.\n\n")

# -----------------------------------------------------------------------------
# Step 3: Find and read the extracted CSV
# -----------------------------------------------------------------------------
csv_files <- list.files(extract_dir, pattern = "\\.csv$",
                        full.names = TRUE, recursive = TRUE)

if (length(csv_files) == 0) {
  stop("No CSV file found after unzipping. The ZIP may be empty or corrupted.")
}

cat("Reading:", csv_files[1], "\n\n")
emp_data <- read_csv(csv_files[1], show_col_types = FALSE)

# -----------------------------------------------------------------------------
# Step 4: Display the data
# -----------------------------------------------------------------------------
cat("=============================================================\n")
cat(" Employee Profile Data\n")
cat("=============================================================\n")
cat("Rows    :", nrow(emp_data), "\n")
cat("Columns :", ncol(emp_data), "\n\n")

print(as.data.frame(emp_data))

# -----------------------------------------------------------------------------
# Step 5: Summary statistics (numeric columns only)
# -----------------------------------------------------------------------------
numeric_cols <- emp_data[, sapply(emp_data, is.numeric)]

if (ncol(numeric_cols) > 0) {
  cat("\n=============================================================\n")
  cat(" Summary Statistics (Numeric Columns)\n")
  cat("=============================================================\n")
  print(summary(numeric_cols))
} else {
  cat("\nNo numeric columns found for summary statistics.\n")
}

cat("\nDone.\n")
